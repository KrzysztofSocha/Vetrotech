﻿namespace Vetrotech.Web.Models.Account
{
    public class TenantChangeModalViewModel
    {
        public string TenancyName { get; set; }
    }
}